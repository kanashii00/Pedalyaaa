#pragma once

// LOCAL SECRETS - not committed.
//
// This file holds the live per-bicycle device key. It is listed in
// firmware/pedalya_lcd/.gitignore so it never reaches the repository.
// Commit secrets_example.h instead, and copy this file on a new machine.
//
// The key below was issued by:
//   php artisan devices:provision-key 1
//
// Only a SHA-256 digest is stored server side, so this plaintext cannot be
// recovered. If it is lost, issue a new one with:
//   php artisan devices:provision-key 1 --rotate

#define WIFI_SSID "PLDTHOMEFIBRZ47rS"
#define WIFI_PASSWORD "PLDTWIFIZ2953"
#define PEDALYA_API_KEY "pedalya-iot-device-key-2024"
#define DEVICE_API_KEY "5d8b9635fccdd62211216fdda22d303612777d02e970294a43a2339101652f62"

// This PC's Wi-Fi address. The 192.168.1.112 default in config.h is stale: this
// machine is on a DHCP lease that hands out .103, and nothing answers on .112.
// Re-check with 'ipconfig' and update if the lease changes.
#define SERVER_HOST "192.168.1.112"
#define SERVER_PORT 8000
